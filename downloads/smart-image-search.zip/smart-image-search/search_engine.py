"""Cached OpenCLIP image/text retrieval extending the original FAISS pipeline."""

import hashlib
import json
import os
import threading
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent


def normalize(vector):
    v = np.asarray(vector, dtype=np.float32).reshape(-1)
    norm = np.linalg.norm(v)
    if not np.isfinite(v).all() or norm < 1e-8:
        raise ValueError("Embedding must be finite and nonzero")
    return v / norm


def crop_image(image, crop):
    """Normalized [left, top, right, bottom], applied after EXIF rotation."""
    image = ImageOps.exif_transpose(image).convert("RGB")
    if crop is None:
        return image
    if len(crop) != 4 or not all(
        isinstance(v, (int, float)) and np.isfinite(v) and 0 <= v <= 1 for v in crop
    ):
        raise ValueError("Crop must contain four normalized coordinates")
    x1, y1, x2, y2 = crop
    w, h = image.size
    box = (int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h))
    if box[2] <= box[0] or box[3] <= box[1]:
        raise ValueError("Crop must have positive pixel area")
    return image.crop(box)


class ClipEncoder:
    def __init__(self):
        import open_clip
        import torch

        self.torch = torch
        name = os.getenv("CLIP_MODEL", "ViT-B-32")
        pretrained = os.getenv("CLIP_PRETRAINED", "laion2b_s34b_b79k")
        self.identity = f"openclip:{name}:{pretrained}"
        self.device = os.getenv(
            "CLIP_DEVICE", "cuda" if torch.cuda.is_available() else "cpu"
        )
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            name, pretrained=pretrained
        )
        self.model.eval().to(self.device)
        self.tokenizer = open_clip.get_tokenizer(name)

    def image(self, image):
        with self.torch.inference_mode():
            v = self.model.encode_image(
                self.preprocess(image).unsqueeze(0).to(self.device)
            )
        return normalize(v.cpu().numpy())

    def text(self, text):
        with self.torch.inference_mode():
            v = self.model.encode_text(self.tokenizer([text]).to(self.device))
        return normalize(v.cpu().numpy())


def read_image(source):
    if source.startswith(("https://", "http://")):
        import requests

        with requests.get(source, timeout=(5, 20), stream=True) as r:
            r.raise_for_status()
            chunks, total = [], 0
            for chunk in r.iter_content(65536):
                total += len(chunk)
                if total > 10 * 1024 * 1024:
                    raise ValueError("Catalog image exceeds 10 MB")
                chunks.append(chunk)
        with Image.open(BytesIO(b"".join(chunks))) as img:
            return crop_image(img, None)
    with Image.open(source) as img:
        return crop_image(img, None)


def load_catalog():
    """Explicit local manifest, MongoDB, or bundled demo manifest."""
    manifest, mongo = os.getenv("CATALOG_PATH"), os.getenv("MONGODB_URI")
    if mongo and not manifest:
        from pymongo import MongoClient

        with MongoClient(mongo, serverSelectionTimeoutMS=5000) as client:
            docs = list(client[os.getenv("MONGODB_DATABASE", "test")].products.find({}))
        rows = []
        for p in docs:
            images = p.get("image", [])
            if images:
                rows.append(
                    dict(
                        id=str(p["_id"]),
                        name=p.get("name", "Product"),
                        image=images[0] if isinstance(images, list) else images,
                    )
                )
    else:
        path = Path(manifest).resolve() if manifest else ROOT / "data/catalog.json"
        rows = json.loads(path.read_text())
        for row in rows:
            if not row["image"].startswith(("http://", "https://")):
                row["image"] = str((path.parent / row["image"]).resolve())
    if not rows:
        raise ValueError("Catalog is empty")
    ids = [str(r["id"]) for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError("Catalog IDs must be unique")
    return [
        dict(id=str(r["id"]), name=str(r.get("name", r["id"])), image=r["image"])
        for r in rows
    ]


class SearchEngine:
    def __init__(self, encoder, rows, cache_dir=None):
        self.encoder, self.rows = encoder, rows
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.index = None
        self.failures = []
        self.lock = threading.RLock()
        self.ready = False

    def build(self, force=False):
        with self.lock:
            if self.ready and not force:
                return
            sources = []
            for r in self.rows:
                p = Path(r["image"])
                sources.append(
                    (
                        r,
                        (
                            (p.stat().st_mtime_ns, p.stat().st_size)
                            if p.is_file()
                            else None
                        ),
                    )
                )
            key = hashlib.sha256(
                json.dumps([self.encoder.identity, sources], sort_keys=True).encode()
            ).hexdigest()
            file = self.cache_dir / f"{key}.npz" if self.cache_dir else None
            vectors = []
            valid = []
            self.failures = []
            if file and file.exists() and not force:
                with np.load(file, allow_pickle=False) as stored:
                    vectors = stored["vectors"]
                    valid = stored["valid"].tolist()
            else:
                for i, row in enumerate(self.rows):
                    try:
                        vectors.append(
                            normalize(self.encoder.image(read_image(row["image"])))
                        )
                        valid.append(i)
                    except Exception as ex:
                        self.failures.append(dict(id=row["id"], error=str(ex)))
                if not valid:
                    raise ValueError("No catalog images could be indexed")
                vectors = np.vstack(vectors).astype("float32")
                if file and not self.failures:
                    file.parent.mkdir(parents=True, exist_ok=True)
                    temp = file.with_suffix(".tmp.npz")
                    np.savez_compressed(temp, vectors=vectors, valid=valid)
                    temp.replace(file)
            self.vectors = np.asarray(vectors, dtype="float32")
            self.valid = valid
            try:
                import faiss

                self.index = faiss.IndexFlatIP(self.vectors.shape[1])
                self.index.add(self.vectors)
            except ImportError:
                self.index = None  # Exact NumPy dot product preserves cosine ranking.
            self.ready = True

    def search(self, image=None, text="", weight=0.35, top_k=6):
        if image is None and not text.strip():
            raise ValueError("Upload an image or enter a description")
        if not 0 <= weight <= 1 or not 1 <= top_k <= 50:
            raise ValueError("Invalid weight or result count")
        with self.lock:
            self.build()
            vi = normalize(self.encoder.image(image)) if image is not None else None
            vt = normalize(self.encoder.text(text.strip())) if text.strip() else None
            query = (
                normalize((1 - weight) * vi + weight * vt)
                if vi is not None and vt is not None
                else (vi if vi is not None else vt)
            )
            count = min(top_k, len(self.valid))
            if self.index is not None:
                scores, indices = self.index.search(query.reshape(1, -1), count)
                pairs = zip(indices[0], scores[0])
            else:
                scores = self.vectors @ query
                indices = np.argsort(-scores, kind="stable")[:count]
                pairs = ((i, scores[i]) for i in indices)
            return [
                dict(
                    id=self.rows[self.valid[int(i)]]["id"],
                    name=self.rows[self.valid[int(i)]]["name"],
                    score=round(float(s), 5),
                )
                for i, s in pairs
                if i >= 0
            ]
