"""Run python ai_server.py, then open http://127.0.0.1:8000/search-lab."""

import json
import threading
from io import BytesIO
from urllib.parse import quote

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from PIL import Image, UnidentifiedImageError
from dotenv import load_dotenv
from search_engine import (
    ROOT,
    ClipEncoder,
    SearchEngine,
    crop_image,
    load_catalog,
    read_image,
)

load_dotenv(ROOT / ".env.local")
load_dotenv(ROOT / ".env")

app = FastAPI(title="Smart Image Search Lab")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
_engine = None
_lock = threading.Lock()


def engine():
    global _engine
    with _lock:
        if _engine is None:
            try:
                _engine = SearchEngine(
                    ClipEncoder(), load_catalog(), ROOT / ".search-cache"
                )
            except Exception as ex:
                raise HTTPException(
                    503,
                    f"Could not initialize search. Install requirements and allow the model download. {ex}",
                ) from ex
    return _engine


@app.get("/")
@app.get("/search-lab")
def home():
    return FileResponse(ROOT / "search_lab.html")


@app.get("/api/status")
def status():
    return dict(
        ready=bool(_engine and _engine.ready),
        indexed=len(_engine.valid) if _engine and _engine.ready else 0,
        model=(
            _engine.encoder.identity if _engine else "OpenCLIP (loads on first search)"
        ),
        failures=_engine.failures if _engine else [],
    )


@app.post("/api/reindex")
def reindex():
    e = engine()
    try:
        with e.lock:
            e.rows = load_catalog()
            e.ready = False
            e.build(force=True)
    except Exception as ex:
        raise HTTPException(503, str(ex)) from ex
    return status()


@app.get("/api/catalog-image/{product_id}")
def catalog_image(product_id: str):
    rows = _engine.rows if _engine else load_catalog()
    row = next((r for r in rows if r["id"] == product_id), None)
    if row is None:
        raise HTTPException(404, "Unknown product")
    try:
        image = read_image(row["image"])
        image.thumbnail((640, 640))
        out = BytesIO()
        image.save(out, format="JPEG")
        return Response(
            out.getvalue(),
            media_type="image/jpeg",
            headers={"Cache-Control": "max-age=300"},
        )
    except Exception as ex:
        raise HTTPException(422, "Could not decode catalog image") from ex


@app.post("/find_similar_products")
def search(
    file: UploadFile | None = File(None),
    text: str = Form(""),
    text_weight: float = Form(0.35),
    top_k: int = Form(6),
    crop: str = Form(""),
):
    if len(text) > 2000 or not 0 <= text_weight <= 1 or not 1 <= top_k <= 50:
        raise HTTPException(422, "Invalid text length, weight, or result count")
    image = None
    try:
        if file is not None:
            data = file.file.read(10 * 1024 * 1024 + 1)
            if len(data) > 10 * 1024 * 1024:
                raise HTTPException(413, "Upload must be under 10 MB")
            with Image.open(BytesIO(data)) as source:
                if source.width * source.height > 20_000_000:
                    raise HTTPException(413, "Image must be under 20 megapixels")
                image = crop_image(source, json.loads(crop) if crop else None)
        elif crop:
            raise ValueError("Crop requires an image")
        if image is None and not text.strip():
            raise ValueError("Upload an image or enter a description")
    except (
        ValueError,
        TypeError,
        UnidentifiedImageError,
        Image.DecompressionBombError,
    ) as ex:
        raise HTTPException(422, str(ex)) from ex
    try:
        hits = engine().search(image, text, text_weight, top_k)
    except HTTPException:
        raise
    except ValueError as ex:
        raise HTTPException(422, str(ex)) from ex
    except Exception as ex:
        raise HTTPException(503, str(ex)) from ex
    for h in hits:
        h["image_url"] = "/api/catalog-image/" + quote(h["id"], safe="")
    return dict(similar_product_ids=[h["id"] for h in hits], results=hits)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
