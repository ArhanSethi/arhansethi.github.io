# Visual Search Lab

An extension of VJ-E/Smart-Image-Search. It adds a standalone crop + text search page and fixes the backend's per-request catalog re-embedding. The full original Next.js store is included.

## Run the search lab on Windows

Install Python 3.12. Extract this ZIP and open a terminal in this folder:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
.venv\Scripts\python -m pip install -r requirements-search.txt
.venv\Scripts\python ai_server.py
```

Or run `setup.bat` once, then `run.bat`. Open **http://127.0.0.1:8000/search-lab**.

On macOS/Linux, use `python3 -m venv .venv`, then `.venv/bin/python` for the pip and server commands. Mac users may install torch/torchvision from the default pip index.

The first search downloads the original project's OpenCLIP ViT-B-32 weights and builds the catalog index. This requires internet access and space for the model. Later searches reuse the in-memory FAISS index; a disk cache reuses embeddings across server restarts. No MongoDB or paid API key is needed for the included local catalog.

**Validation limit:** network approval for the model download was cancelled in the build environment. Real pretrained model inference could not be completed here. Crop handling, weighted fusion, caching, FAISS ranking, HTTP routes, and browser interactions were tested using deterministic test embeddings / a stubbed UI response. No mock encoder is selected by the shipped application.

## Search

1. Upload a reference image (under 10 MB / 20 megapixels).
2. Drag across the preview to select the relevant region; Reset crop restores the whole image.
3. Optionally enter a description and adjust Text influence.
4. Search. You can also search with text alone.

Combined queries normalize `(1-weight) × image_embedding + weight × text_embedding`. This is weighted CLIP retrieval, not an image-editing model: comparative phrases such as “darker” are approximate. Describe desired attributes directly for more predictable results. Similarity is not a calibrated confidence probability.

## Bring your own catalog

`data/catalog.json` contains 12 synthetic garment illustrations included solely for a runnable demonstration. Replace it with a JSON array:

```json
[
  {"id":"jacket-001", "name":"Dark denim jacket", "image":"images/jacket.jpg"},
  {"id":"shirt-002", "name":"Cream shirt", "image":"images/shirt.jpg"}
]
```

Image paths are relative to the manifest; trusted HTTP(S) image URLs are also supported. IDs must be unique. Set `CATALOG_PATH` to choose a different manifest. Click **Rebuild catalog index** after editing it. Failed images are counted in status. Remote image changes require an explicit rebuild.

If `MONGODB_URI` is set and `CATALOG_PATH` is not, the backend reads the original store's `products` collection in the `test` database. It supports the original `image` URL array and MongoDB `_id` values. Set `MONGODB_DATABASE` to change the database. `.env.local` and `.env` are loaded at startup; keep credentials private.

Optional environment variables: `CLIP_MODEL`, `CLIP_PRETRAINED` (a supported pretrained tag or local checkpoint path), `CLIP_DEVICE`, `CATALOG_PATH`, `MONGODB_URI`, `MONGODB_DATABASE`.

## Existing Next.js store

The original storefront and checkout code remain in `src/`. Its navigation now links to the search lab, and the original upload-only flow still receives `similar_product_ids`. Set `NEXT_PUBLIC_SEARCH_API_URL` if the Python service is not at `http://localhost:8000`. Follow the upstream README for MongoDB, Cloudinary, Stripe, and storefront setup. Those external storefront integrations were not end-to-end tested in this build.

## Code and tests

- `search_engine.py`: real OpenCLIP encoders, normalized fusion, local/MongoDB catalog loading, reusable FAISS index and `.npz` cache. A NumPy exact-dot-product fallback works when FAISS is not installed.
- `ai_server.py`: API, validation, crop support, status, reindex, and catalog image serving.
- `search_lab.html`: responsive query and crop interface.
- `legacy_ai_server.py`: the unmodified original backend, retained for comparison.
- `test_search.py`: deterministic tests; its fake encoder is used only in tests.

```sh
python -m pip install pytest httpx
python -m pytest test_search.py -q
```

The service binds to loopback and is intended for local development. Model weights, environment files, and generated indexes are not bundled.
