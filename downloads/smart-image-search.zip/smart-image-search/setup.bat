@echo off
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto error
.venv\Scripts\python -m pip install -r requirements-search.txt
if errorlevel 1 goto error
echo Setup complete. Run run.bat next.
pause
exit /b 0
:error
echo Setup failed. Install Python 3.12 and read START_HERE.md.
pause
exit /b 1
