# Upstream attribution

This is an extended copy of [VJ-E/Smart-Image-Search](https://github.com/VJ-E/Smart-Image-Search), based on commit `ebc00b0fae2553dbe4dd19c3748cf71e2191d9ca`.

The original authors own their original contributions. Their license, copyright notices, source files, and README are retained. New work is described in START_HERE.md and CHANGES.md. This package does not claim original authorship of the upstream project.

Extension title: Visual Search Lab. New extension code is made available under the repository's MIT license terms.
