from io import BytesIO

import ai_server
import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image
from search_engine import SearchEngine, crop_image


class Encoder:
    identity = "test-colors-v1"
    calls = 0

    def image(self, image):
        self.calls += 1
        return np.asarray(image).mean(axis=(0, 1))

    def text(self, text):
        return {"blue": [0, 0, 1], "red": [1, 0, 0]}[text]


def setup_engine(tmp_path):
    rows = []
    for name, color in [("red", (255, 0, 0)), ("blue", (0, 0, 255))]:
        path = tmp_path / f"{name}.png"
        Image.new("RGB", (20, 20), color).save(path)
        rows.append(dict(id=name, name=name, image=str(path)))
    return SearchEngine(Encoder(), rows, tmp_path / "cache")


def test_cache_and_weight_change(tmp_path):
    e = setup_engine(tmp_path)
    e.build()
    calls = e.encoder.calls
    assert e.search(text="blue", top_k=50)[0]["id"] == "blue"
    assert e.encoder.calls == calls
    image = Image.new("RGB", (20, 20), "red")
    assert e.search(image, "blue", 0)[0]["id"] == "red"
    assert e.search(image, "blue", 1)[0]["id"] == "blue"
    assert len(e.search(text="blue", top_k=50)) == 2
    other = SearchEngine(Encoder(), e.rows, tmp_path / "cache")
    other.build()
    assert other.encoder.calls == 0


def test_crop_and_api(tmp_path, monkeypatch):
    assert crop_image(Image.new("RGB", (100, 100)), [0, 0.2, 0.5, 0.8]).size == (50, 60)
    with pytest.raises(ValueError):
        crop_image(Image.new("RGB", (10, 10)), [0.8, 0, 0.2, 1])
    monkeypatch.setattr(ai_server, "_engine", setup_engine(tmp_path))
    c = TestClient(ai_server.app)
    assert c.get("/search-lab").status_code == 200
    assert c.post("/find_similar_products").status_code == 422
    assert (
        c.post(
            "/find_similar_products", files={"file": ("bad.png", b"bad")}
        ).status_code
        == 422
    )
    assert (
        c.post("/find_similar_products", data={"text": "blue", "top_k": 99}).status_code
        == 422
    )
    out = BytesIO()
    Image.new("RGB", (20, 20), "red").save(out, format="PNG")
    r = c.post(
        "/find_similar_products",
        files={"file": ("red.png", out.getvalue())},
        data={"text": "blue", "text_weight": 1},
    )
    assert r.status_code == 200 and r.json()["similar_product_ids"][0] == "blue"
    assert c.get("/api/catalog-image/blue").status_code == 200
