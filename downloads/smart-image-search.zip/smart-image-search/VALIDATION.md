# Validation

Validation was performed on Linux / Python 3.12.

- 2 regression tests passed, covering persistent embedding reuse, weighted query ranking, top-k bounds, crop validation, API errors, legacy result IDs and catalog image serving. FAISS was installed for the final run.
- Browser checks passed for image upload, normalized crop submission, text query submission, rendering results, and a 390px mobile viewport. No JavaScript exceptions occurred.
- The browser search response was stubbed, and backend tests used deterministic embeddings. Real CLIP model download was blocked by cancelled network approval in this environment; pretrained inference remains unverified here. The application itself uses real OpenCLIP, with no demo-encoder fallback.
- Original Next.js storefront integrations requiring MongoDB, Cloudinary and Stripe were not end-to-end exercised.
