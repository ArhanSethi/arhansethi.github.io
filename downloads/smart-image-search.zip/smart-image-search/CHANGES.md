# Extension changes

- Replaces ai_server.py with a compatible search endpoint supporting image-only, text-only and weighted image/text queries.
- Adds EXIF-aware normalized cropping, bounded image uploads and catalog reindex/status endpoints.
- Adds persistent embedding cache and reusable FAISS index instead of regenerating catalog embeddings on every query.
- Adds standalone responsive search_lab.html and links it from the existing Next.js navigation.
- Adds a local catalog option and 12 clearly synthetic demo illustrations.
- Retains the original backend as legacy_ai_server.py and retains the original storefront source.

See START_HERE.md for setup, limits, and source-file responsibilities.
