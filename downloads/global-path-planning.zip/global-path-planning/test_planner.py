import pytest
from planner import Planner, Scene, length, smooth


def test_thin_obstacle_and_clearance():
    s = Scene(obstacles=[[400, 100, 0.01, 400]])
    assert not s.visible((10, 300), (890, 300))
    assert not s.free((399, 300))
    assert s.visible((10, 50), (890, 50))


def test_endpoints_smoothing_and_repeatability():
    s = Scene()
    a, b = Planner(s, seed=5), Planner(s, seed=5)
    a.advance(900)
    b.advance(900)
    assert a.path() == b.path()
    path = a.path()
    assert path and path[0] == s.start and path[-1] == s.goal
    for p in (path, smooth(path, s)):
        assert all(s.visible(x, y) for x, y in zip(p, p[1:]))
    assert length(smooth(path, s)) <= length(path)


def test_unreachable_and_invalid_start():
    s = Scene(obstacles=[[400, 0, 50, 600]])
    p = Planner(s)
    p.advance(400)
    assert p.path() == []
    with pytest.raises(ValueError):
        Planner(Scene(start=(400, 300), obstacles=[[390, 0, 50, 600]]))


def test_rrt_star_cost_does_not_regress():
    p = Planner(Scene(), seed=42)
    p.advance(700)
    before = length(p.path())
    assert before > 0
    p.advance(400)
    assert length(p.path()) <= before + 1e-8
