"""Run `python app.py` for the interactive planning workbench."""

import argparse
import csv
import json
from dataclasses import asdict
from pathlib import Path

import pygame
from planner import Planner, Scene, smooth


def main():
    args = argparse.ArgumentParser()
    args.add_argument(
        "--smoke", action="store_true", help="Render one frame and save smoke.png"
    )
    smoke = args.parse_args().smoke
    pygame.init()
    screen = pygame.display.set_mode((1200, 780))
    pygame.display.set_caption("Path Lab | RRT / RRT*")
    font = pygame.font.SysFont("DejaVu Sans", 16)
    title = pygame.font.SysFont("DejaVu Sans", 27, bold=True)
    clock = pygame.time.Clock()
    scene, seed, mode, selected = Scene(), 42, "obstacle", "RRT*"
    planners, running, drag, message = (
        {},
        False,
        None,
        "Draw obstacles, then press Space.",
    )
    benchmark = []

    def reset():
        nonlocal planners, running
        planners, running = {}, False

    def text(value, x, y, color=(188, 199, 218), big=False):
        screen.blit((title if big else font).render(str(value), True, color), (x, y))

    alive = True
    while alive:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                alive = False
            if e.type == pygame.KEYDOWN:
                try:
                    if e.key == pygame.K_SPACE:
                        if not planners:
                            planners = {
                                a: Planner(scene, a, seed) for a in ("RRT", "RRT*")
                            }
                        running = not running
                    elif e.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        mode = {
                            pygame.K_1: "obstacle",
                            pygame.K_2: "start",
                            pygame.K_3: "goal",
                        }[e.key]
                    elif e.key == pygame.K_TAB:
                        selected = "RRT" if selected == "RRT*" else "RRT*"
                    elif e.key == pygame.K_r:
                        reset()
                    elif e.key == pygame.K_c:
                        scene.obstacles = []
                        reset()
                    elif e.key == pygame.K_n:
                        seed += 1
                        reset()
                    elif e.key == pygame.K_s:
                        Path("map.json").write_text(json.dumps(asdict(scene), indent=2))
                        message = "Saved map.json"
                    elif e.key == pygame.K_l:
                        candidate = Scene(**json.loads(Path("map.json").read_text()))
                        if (candidate.width, candidate.height) != (900, 600):
                            raise ValueError("Editor requires a 900 x 600 map")
                        scene = candidate
                        reset()
                        message = "Loaded map.json"
                    elif e.key == pygame.K_e:
                        data = {
                            a: dict(
                                p.metrics(),
                                path=p.path(),
                                smoothed_path=smooth(p.path(), scene),
                            )
                            for a, p in planners.items()
                        }
                        Path("results.json").write_text(
                            json.dumps(
                                dict(
                                    seed=seed,
                                    scene=asdict(scene),
                                    results=data,
                                    benchmark=benchmark,
                                ),
                                indent=2,
                            )
                        )
                        message = "Saved results.json"
                    elif e.key == pygame.K_b:
                        running = False
                        benchmark = []
                        for trial in range(5):
                            for a in ("RRT", "RRT*"):
                                p = Planner(scene, a, seed + trial)
                                p.advance(800)
                                benchmark.append(dict(seed=seed + trial, **p.metrics()))
                            pygame.event.pump()
                        with open("benchmark.csv", "w", newline="") as f:
                            writer = csv.DictWriter(f, fieldnames=benchmark[0].keys())
                            writer.writeheader()
                            writer.writerows(benchmark)
                        message = "5-seed benchmark saved to benchmark.csv"
                except (ValueError, OSError, TypeError) as ex:
                    message = str(ex)
            if (
                e.type == pygame.MOUSEBUTTONDOWN
                and e.pos[0] < 900
                and 80 <= e.pos[1] < 680
            ):
                p = (e.pos[0], e.pos[1] - 80)
                reset()
                if e.button == 3:
                    scene.obstacles = [
                        r for r in scene.obstacles if not pygame.Rect(r).collidepoint(p)
                    ]
                elif e.button == 1:
                    if mode == "obstacle":
                        drag = p
                    elif scene.free(p):
                        setattr(scene, mode, p)
                    else:
                        message = "Choose a point with clearance from obstacles."
            if e.type == pygame.MOUSEBUTTONUP and e.button == 1 and drag:
                x, y = max(0, min(900, e.pos[0])), max(0, min(600, e.pos[1] - 80))
                rect = [
                    min(drag[0], x),
                    min(drag[1], y),
                    abs(x - drag[0]),
                    abs(y - drag[1]),
                ]
                if min(rect[2:]) >= 5:
                    scene.obstacles.append(rect)
                    if not scene.free(scene.start) or not scene.free(scene.goal):
                        scene.obstacles.pop()
                        message = "Obstacle would cover start or goal clearance."
                drag = None
        if running:
            for p in planners.values():
                if p.iterations < 2000:
                    p.advance(4)
            if all(p.iterations >= 2000 for p in planners.values()):
                running = False
        screen.fill((15, 21, 34))
        text("PATH LAB", 24, 18, (240, 245, 255), True)
        text("Sampling-based motion planning", 215, 30)
        canvas = screen.subsurface((0, 80, 900, 600))
        canvas.fill((23, 32, 47))
        for x in range(0, 900, 30):
            pygame.draw.line(canvas, (29, 40, 56), (x, 0), (x, 600))
        for y in range(0, 600, 30):
            pygame.draw.line(canvas, (29, 40, 56), (0, y), (900, y))
        for rect in scene.obstacles:
            pygame.draw.rect(canvas, (62, 76, 98), rect, border_radius=3)
        p = planners.get(selected)
        if p:
            for node in p.nodes:
                if node.parent:
                    pygame.draw.line(
                        canvas, (59, 87, 117), node.coordinates, node.parent.coordinates
                    )
            path = p.path()
            if len(path) > 1:
                pygame.draw.lines(canvas, (237, 169, 85), False, path, 3)
                pygame.draw.lines(canvas, (77, 225, 185), False, smooth(path, scene), 4)
        if drag:
            mx, my = pygame.mouse.get_pos()
            r = pygame.Rect(drag, (mx - drag[0], my - 80 - drag[1]))
            r.normalize()
            pygame.draw.rect(canvas, (103, 139, 181), r, 2)
        pygame.draw.circle(canvas, (77, 225, 185), scene.start, 9)
        pygame.draw.circle(canvas, (245, 139, 154), scene.goal, 9)
        text("COMPARISON", 924, 92, (240, 245, 255), True)
        text(f"View: {selected}   Seed: {seed}", 924, 140)
        text("Running" if running else "Paused / ready", 924, 170, (77, 225, 185))
        y = 215
        for a in ("RRT", "RRT*"):
            text(a, 924, y, (240, 245, 255), True)
            if a in planners:
                m = planners[a].metrics()
                for k in (
                    "iterations",
                    "nodes",
                    "length",
                    "smoothed_length",
                    "runtime_ms",
                ):
                    value = m[k]
                    text(
                        f"{k}: {round(value,1) if isinstance(value,float) else value}",
                        924,
                        y + 40,
                    )
                    y += 27
            y += 70
        if benchmark:
            for a in ("RRT", "RRT*"):
                wins = sum(r["success"] for r in benchmark if r["algorithm"] == a)
                text(f"{a} success: {wins}/5", 924, y)
                y += 26
        text(
            f"EDIT MODE: {mode.upper()}   |   Green: smoothed path / Orange: raw path",
            24,
            697,
        )
        text(
            "1 Obstacle   2 Start   3 Goal   Right-click delete   Space Run/Pause   Tab Switch tree",
            24,
            727,
        )
        text(
            "R Reset   C Clear   N Seed+1   S Save map   L Load map   B Benchmark   E Export",
            24,
            752,
        )
        text(message[:82], 500, 28)
        pygame.display.flip()
        if smoke:
            pygame.image.save(screen, "smoke.png")
            alive = False
        clock.tick(60)
    pygame.quit()


if __name__ == "__main__":
    main()
