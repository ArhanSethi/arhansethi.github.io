# Upstream attribution

This is an extended copy of [KianRafati/Global-Path-Planning](https://github.com/KianRafati/Global-Path-Planning), based on commit `9e77adc18705c48a223d51aa9d71a56dca533c43`.

The original authors own their original contributions. Their license, copyright notices, source files, and README are retained. New work is described in START_HERE.md and CHANGES.md. This package does not claim original authorship of the upstream project.

Extension title: Path Lab. New extension code is made available under the repository's MIT license terms.
