"""Deterministic RRT/RRT* extension using upstream Node and RRTGraph types."""

from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field

from RRTbasePy import Node, RRTGraph


@dataclass
class Scene:
    width: int = 900
    height: int = 600
    start: tuple[float, float] = (70, 300)
    goal: tuple[float, float] = (820, 300)
    obstacles: list = field(
        default_factory=lambda: [[270, 0, 65, 380], [540, 220, 65, 380]]
    )
    clearance: float = 8

    def __post_init__(self):
        values = [self.width, self.height, self.clearance, *self.start, *self.goal]
        if (
            not all(math.isfinite(v) for v in values)
            or self.width <= 0
            or self.height <= 0
            or self.clearance < 0
        ):
            raise ValueError("Invalid map dimensions or clearance")
        for rect in self.obstacles:
            if (
                len(rect) != 4
                or not all(math.isfinite(v) for v in rect)
                or min(rect[2:]) <= 0
            ):
                raise ValueError(
                    "Obstacles require finite x, y and positive width, height"
                )

    def free(self, p):
        x, y = p
        c = self.clearance
        return (
            c <= x <= self.width - c
            and c <= y <= self.height - c
            and not any(
                ox - c <= x <= ox + w + c and oy - c <= y <= oy + h + c
                for ox, oy, w, h in self.obstacles
            )
        )

    def visible(self, a, b):
        """Exact slab segment/rectangle intersection, including boundary contact."""
        if not self.free(a) or not self.free(b):
            return False
        for x, y, w, h in self.obstacles:
            c = self.clearance
            lo, hi = 0.0, 1.0
            for origin, delta, lower, upper in (
                (a[0], b[0] - a[0], x - c, x + w + c),
                (a[1], b[1] - a[1], y - c, y + h + c),
            ):
                if abs(delta) < 1e-12:
                    if not lower <= origin <= upper:
                        lo, hi = 1, 0
                        break
                else:
                    t1, t2 = sorted(
                        ((lower - origin) / delta, (upper - origin) / delta)
                    )
                    lo, hi = max(lo, t1), min(hi, t2)
            if lo <= hi:
                return False
        return True


def length(path):
    return sum(math.dist(a, b) for a, b in zip(path, path[1:]))


def smooth(path, scene):
    """Shortcut only when the replacement segment preserves clearance."""
    if not path:
        return []
    result, i = [path[0]], 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1 and not scene.visible(path[i], path[j]):
            j -= 1
        result.append(path[j])
        i = j
    return result


class Planner(RRTGraph):
    def __init__(self, scene, algorithm="RRT*", seed=42, step=40):
        if algorithm not in ("RRT", "RRT*"):
            raise ValueError("Choose RRT or RRT*")
        if not scene.free(scene.start) or not scene.free(scene.goal):
            raise ValueError("Start and goal must have obstacle and wall clearance")
        if step <= 0:
            raise ValueError("Step must be positive")
        super().__init__(
            scene.start, scene.goal, (scene.height, scene.width), scene.obstacles
        )
        del self.path  # Upstream stores a list under the new method's name.
        self.scene, self.algorithm, self.step_size = scene, algorithm, step
        self.rng = random.Random(seed)
        self.iterations, self.runtime = 0, 0.0

    def cost(self, node):
        total = 0.0
        while node.parent is not None:
            total += self.distance(node, node.parent)
            node = node.parent
        return total

    def advance(self, count=1):
        begin = time.perf_counter()
        for _ in range(count):
            self.iterations += 1
            target = (
                self.scene.goal
                if self.rng.random() < 0.08
                else (self.rng.uniform(0, self.MapW), self.rng.uniform(0, self.MapH))
            )
            near = self.findNearRRT(Node(*target))
            dist = math.dist(near.coordinates, target)
            if dist < 1e-8:
                continue
            ratio = min(1, self.step_size / dist)
            p = tuple(a + (b - a) * ratio for a, b in zip(near.coordinates, target))
            if not self.scene.visible(near.coordinates, p):
                continue
            new = Node(*p)
            neighbors = (
                [n for n in self.nodes if self.distance(n, new) <= 100]
                if self.algorithm == "RRT*"
                else []
            )
            parent = near
            best = self.cost(near) + self.distance(near, new)
            for n in neighbors:
                cost = self.cost(n) + self.distance(n, new)
                if cost < best and self.scene.visible(n.coordinates, p):
                    parent, best = n, cost
            self.addEdge(parent, new)
            self.add_node(new)
            for n in neighbors:
                if (
                    n.parent is not None
                    and best + self.distance(new, n) + 1e-9 < self.cost(n)
                    and self.scene.visible(p, n.coordinates)
                ):
                    self.addEdge(new, n)
        self.runtime += time.perf_counter() - begin

    def path(self):
        candidates = [
            n
            for n in self.nodes
            if math.dist(n.coordinates, self.scene.goal) <= 100
            and self.scene.visible(n.coordinates, self.scene.goal)
        ]
        if not candidates:
            return []
        node = min(
            candidates,
            key=lambda n: self.cost(n) + math.dist(n.coordinates, self.scene.goal),
        )
        path = [self.scene.goal]
        while node is not None:
            if node.coordinates != path[-1]:
                path.append(node.coordinates)
            node = node.parent
        return list(reversed(path))

    def metrics(self):
        p = self.path()
        return dict(
            algorithm=self.algorithm,
            iterations=self.iterations,
            nodes=len(self.nodes),
            success=bool(p),
            length=length(p) if p else None,
            smoothed_length=length(smooth(p, self.scene)) if p else None,
            runtime_ms=round(self.runtime * 1000, 2),
        )
