# Path Lab

An extension of KianRafati/Global-Path-Planning. The original `RRT.py` and `RRTbasePy.py` are retained. Start the new workbench with `app.py`.

## Run on Windows

Install Python 3.12, extract the ZIP, and open a terminal in this folder:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```

Or run `setup.bat` once, then `run.bat`.

On macOS/Linux:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

## Use it

The canvas is 900 × 600 pixels. Green is start, pink is goal. Clearance is an 8-pixel robot radius by default. Press Space to run both algorithms with identical seeds and iteration budgets; Tab switches the displayed tree. Orange is the raw path, mint is its collision-checked shortcut path.

| Key/action | Effect |
|---|---|
| 1, then drag | Draw a rectangular obstacle |
| 2, then click | Move start |
| 3, then click | Move goal |
| Right-click obstacle | Delete it |
| Space | Start / pause both planners |
| Tab | Switch RRT / RRT* tree |
| R | Reset trees |
| C | Clear obstacles |
| N | Increment seed and reset |
| S / L | Save / load `map.json` in this folder |
| B | Compare 5 seeds × 800 iterations; save `benchmark.csv` |
| E | Save map, seed, paths, metrics, and latest benchmark to `results.json` |

Editing geometry resets the trees. Endpoints cannot sit inside inflated obstacles. Interactive runs stop after 2,000 iterations. Use the benchmark CLI for a larger budget:

```sh
python benchmark.py --trials 20 --iterations 2000 --seed 42 --output benchmark.csv
python benchmark.py --map map.json --trials 10
```

`example-benchmark.csv` is an actual 10-seed run on the default scene. Runtime is local CPU planning time, excluding rendering. Length is in pixels, and failures have empty length fields. Success rate is specific to the chosen map and finite sample budget.

## Code map

- `planner.py`: reusable scene geometry, exact segment/rectangle collision checking, deterministic planner, iterative cost calculation, goal connection and path smoothing.
- `app.py`: Pygame obstacle editor, rendering, comparison and exports.
- `benchmark.py`: headless experiment runner.
- `test_planner.py`: collision, reproducibility, endpoint and non-regressing RRT* path tests.

```sh
python -m pip install pytest
python -m pytest test_planner.py -q
```

This is 2D geometric planning with rectangular obstacles, not a robot dynamics simulator. RRT* uses a fixed 100-pixel rewiring neighborhood; no convergence or real-robot safety guarantees are claimed. Shortcut smoothing does not impose curvature or acceleration constraints.
