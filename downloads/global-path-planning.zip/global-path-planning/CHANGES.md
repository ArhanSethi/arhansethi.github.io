# Extension changes

- Reuses the original Node and RRTGraph data structures in a deterministic planner subclass.
- Adds explicit goal connection, exact slab-based collision checking with clearance, iterative path cost and shortcut smoothing.
- Adds interactive map editing, seeded RRT/RRT* comparison, JSON exports and CSV benchmark CLI.
- Retains original RRT.py and RRTbasePy.py without modifications.

See START_HERE.md for setup, limits, and source-file responsibilities.
