"""Run headless, reproducible RRT/RRT* comparisons with equal iteration budgets."""

import argparse
import csv
import json
from pathlib import Path

from planner import Planner, Scene


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--map", type=Path)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--trials", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--output", type=Path, default=Path("benchmark.csv"))
    args = parser.parse_args()
    if args.trials < 1 or args.iterations < 1:
        parser.error("Trials and iterations must be positive")
    scene = Scene(**json.loads(args.map.read_text())) if args.map else Scene()
    rows = []
    for seed in range(args.seed, args.seed + args.trials):
        for algorithm in ("RRT", "RRT*"):
            planner = Planner(scene, algorithm, seed)
            planner.advance(args.iterations)
            rows.append(dict(seed=seed, **planner.metrics()))
    with args.output.open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    for algorithm in ("RRT", "RRT*"):
        valid = [r for r in rows if r["algorithm"] == algorithm and r["success"]]
        mean = sum(r["length"] for r in valid) / len(valid) if valid else None
        print(
            f"{algorithm}: {len(valid)}/{args.trials} successful, mean successful path length={mean}"
        )
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
