# Validation

Validation was performed on Linux / Python 3.12.

- 4 regression tests passed: thin obstacles/clearance, deterministic runs, endpoint validity, unreachable maps, and non-regressing RRT* path cost.
- Pygame launched with SDL's dummy video driver; screenshot inspected.
- 10 seeds × 1,000 iterations on the default map: RRT 10/10 successful, mean raw length 1210.646 px; RRT* 10/10 successful, mean raw length 884.967 px. See example-benchmark.csv. These are local experiment results, not a general performance claim.
