@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python -m review_lab
) else (
 py -3.12 -m review_lab
)
pause
