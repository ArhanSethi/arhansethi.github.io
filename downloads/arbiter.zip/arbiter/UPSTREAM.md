# Upstream attribution

This is an extended copy of [ashita-ai/arbiter](https://github.com/ashita-ai/arbiter), based on commit `85ac9fc67623d0cac8dceeb26cfd54035d832bee`.

The original authors own their original contributions. Their license, copyright notices, source files, and README are retained. New work is described in START_HERE.md and CHANGES.md. This package does not claim original authorship of the upstream project.

Extension title: Arbiter Review Lab. New extension code is made available under the repository's MIT license terms.
