# Arbiter Review Lab

A local review dashboard built on ashita-ai/arbiter's existing `compare()` API. The core library and its public API are unchanged.

## Start without API keys or extra dependencies

Install Python 3.11+ (3.12 recommended), extract the ZIP, and open a terminal here:

```powershell
py -3.12 -m review_lab
```

On macOS/Linux: `python3 -m review_lab`. Windows users can double-click `run.bat`.

Open **http://127.0.0.1:8011**. Click **Load sample pairs**. These are explicitly illustrative responses, not outputs or measured scores from real models.

Choose a reviewer name, read the anonymized pair, and vote A, B, or Tie. The server randomizes left/right order separately for each reviewer and case. It reveals names only after that reviewer votes. Votes persist in `review_lab/reviews.sqlite3`; changing a vote updates the same record.

The response table summarizes human wins/ties and any generation cost/latency you supply. The judge table reports human/judge agreement, Cohen's kappa, latest stored judge-call costs, and judge latency. Missing measurements stay blank. A tie is a third class in the agreement calculation; kappa is undefined if expected agreement is 1.

## Optional live Arbiter judge

Install the original library in a virtual environment:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -e .
.venv\Scripts\python -m review_lab
```

Set your provider's normal API-key environment variable in your terminal before launching. Keys are never entered in the UI or saved in the review database. Select a provider, enter an available exact model ID and criteria, then click **Run paid API evaluation**. The server calls the upstream public `compare()` function; each request has a 60-second timeout. Additional providers may need the corresponding upstream optional dependency.

No paid judge calls were made during validation. The adapter was tested with a real Arbiter result object and a mocked provider call. Provider keys are needed to verify live model behavior on your machine.

## Import cases

Import a JSON **array** with one object per pair:

```json
[
  {
    "id":"case-001",
    "prompt":"Explain cache invalidation.",
    "model_a":"your-first-model",
    "model_b":"your-second-model",
    "output_a":"First response text",
    "output_b":"Second response text",
    "latency_a_ms":120,
    "latency_b_ms":180,
    "cost_a_usd":0.0002,
    "cost_b_usd":0.0004
  }
]
```

The four latency/cost fields are optional and must be real measurements if supplied. Imports are atomic. A conflicting existing ID is rejected to preserve vote meaning; use a new ID for changed outputs. Limits: 1,000 cases per import and 5 MB per HTTP request.

**Export records** downloads cases, votes, and latest judge verdicts for analysis. To import its cases elsewhere, use its `cases` array. To back up or restore all votes and blinding assignments, copy the SQLite file while the server is stopped. `--db PATH` or `ARBITER_REVIEW_DB` selects another database; `--port 8013` changes the port.

## Scope and interpretation

This is a loopback-only, single-user workbench with reviewer labels, not an authenticated multi-user research service. Deliberate inspection of source data/export can reveal identities. Sample size matters: agreement observations from multiple reviewers on the same case are correlated. Use consistent criteria across a judge comparison. Re-evaluating a case with the same provider/model replaces its latest verdict; the displayed cost is not cumulative billing history. No response generation is performed: import the outputs you want to compare.

## Code and validation

- `review_lab/store.py`: transactional SQLite data, blind presentation, votes, agreement and model summaries.
- `review_lab/__main__.py`: standard-library HTTP server and live Arbiter adapter.
- `review_lab/index.html`: dashboard.
- `review_lab/demo.json`: sample pairs.
- `review_lab/test_store.py`: persistence, validation, agreement, HTTP and adapter tests.

```sh
python -m pip install -e . pytest pytest-cov
python -m pytest review_lab/test_store.py -o addopts="" -q
```

The adapter test imports the core library, so install it before running the complete extension test file. The core upstream suite passed 955 tests (15 skipped) with its optional test dependencies available.
