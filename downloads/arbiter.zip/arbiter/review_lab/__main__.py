"""Local HTTP interface. Start with python -m review_lab."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .store import Store

ROOT = Path(__file__).resolve().parent


async def run_judge(
    row: dict[str, Any], provider: str, model: str, criteria: str
) -> dict[str, Any]:
    """Call Arbiter's existing public API; keys stay in provider environment vars."""
    from arbiter_ai import compare
    from arbiter_ai.core.types import Provider

    result = await compare(
        output_a=row["output_a"],
        output_b=row["output_b"],
        reference=row["prompt"],
        criteria=criteria,
        provider=Provider(provider),
        model=model,
        timeout=60,
    )
    cost = None
    try:
        cost = await result.total_llm_cost()
    except Exception:
        # An unavailable price must not be displayed as a free call.
        cost = None
    return dict(
        winner=result.winner,
        confidence=result.confidence,
        reasoning=result.reasoning,
        cost_usd=cost,
        latency_ms=result.processing_time * 1000,
        total_tokens=result.total_tokens,
        criteria=criteria,
        source="live Arbiter comparison",
    )


def handler_for(store: Store) -> type[BaseHTTPRequestHandler]:
    """Create a request handler bound to this workbench database."""

    class Handler(BaseHTTPRequestHandler):
        def send_json(self, value: object, status: int = 200) -> None:
            """Write one JSON response."""
            data = json.dumps(value, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            """Serve the UI, blind cases, aggregate metrics, or explicit export."""
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)
            try:
                if parsed.path == "/":
                    data = (ROOT / "index.html").read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                elif parsed.path == "/api/cases":
                    self.send_json(
                        [dict(id=r["id"], prompt=r["prompt"]) for r in store.cases()]
                    )
                elif parsed.path == "/api/case":
                    self.send_json(
                        store.blind_case(params["id"][0], params["rater"][0])
                    )
                elif parsed.path == "/api/stats":
                    self.send_json(store.stats())
                elif parsed.path == "/api/export":
                    self.send_json(store.export())
                else:
                    self.send_json({"error": "Not found"}, 404)
            except (ValueError, KeyError) as ex:
                self.send_json({"error": str(ex)}, 400)

        def do_POST(self) -> None:
            """Apply JSON-only mutations from this loopback origin."""
            origin = self.headers.get("Origin")
            if origin and origin != "http://" + self.headers.get("Host", ""):
                self.send_json({"error": "Origin mismatch"}, 403)
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if (
                    not 0 < size <= 5_000_000
                    or "application/json" not in self.headers.get("Content-Type", "")
                ):
                    raise ValueError("Send JSON under 5 MB")
                payload = json.loads(self.rfile.read(size))
                if self.path == "/api/import":
                    self.send_json({"imported": store.import_cases(payload)})
                elif self.path == "/api/demo":
                    rows = json.loads((ROOT / "demo.json").read_text())
                    store.import_cases(rows)
                    self.send_json({"imported": len(rows)})
                elif self.path == "/api/vote":
                    store.vote(payload["id"], payload["rater"], payload["choice"])
                    self.send_json({"saved": True})
                elif self.path == "/api/judge":
                    model = str(payload["model"]).strip()
                    criteria = str(payload.get("criteria", "")).strip()
                    if not model or not criteria:
                        raise ValueError("Judge model and criteria are required")
                    row = store.case(payload["id"])
                    result = asyncio.run(
                        run_judge(row, payload["provider"], model, criteria)
                    )
                    store.judge(row["id"], payload["provider"], model, result)
                    self.send_json({"saved": True})
                else:
                    self.send_json({"error": "Not found"}, 404)
            except (ValueError, KeyError, TypeError) as ex:
                self.send_json({"error": str(ex)}, 400)
            except Exception as ex:
                self.send_json(
                    {
                        "error": f"{type(ex).__name__}: Judge unavailable. Check the provider environment variable, model name, and terminal log."
                    },
                    503,
                )

    return Handler


def main() -> None:
    """Start the loopback-only workbench using an explicit persistent database."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8011)
    parser.add_argument(
        "--db", default=os.getenv("ARBITER_REVIEW_DB", str(ROOT / "reviews.sqlite3"))
    )
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_for(Store(args.db)))
    print(f"Arbiter Review Lab: http://127.0.0.1:{args.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
