"""SQLite review records and agreement statistics; independent of LLM providers."""

from __future__ import annotations

import hashlib
import json
import math
import secrets
import sqlite3
from collections import Counter
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

# Heterogeneous JSON crosses the import/export boundary; values are validated here.
Record = dict[str, Any]
WINNERS = ("output_a", "output_b", "tie")


def agreement(pairs: list[tuple[str, str]]) -> Record:
    """Exact agreement and Cohen's kappa, including ties as a third class."""
    n = len(pairs)
    if not n:
        return {"n": 0, "agreement": None, "kappa": None}
    observed = sum(a == b for a, b in pairs) / n
    a_counts, b_counts = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    expected = sum(a_counts[k] * b_counts[k] for k in WINNERS) / n**2
    return {
        "n": n,
        "agreement": observed,
        "kappa": (observed - expected) / (1 - expected) if expected < 1 else None,
    }


def validate_case(row: Record) -> Record:
    """Validate an imported pair; IDs are immutable once imported."""
    if not isinstance(row, dict):
        raise ValueError("Each case must be a JSON object")
    fields = ("id", "prompt", "model_a", "model_b", "output_a", "output_b")
    for key in fields:
        if (
            not isinstance(row.get(key), str)
            or not row[key].strip()
            or len(row[key]) > 100_000
        ):
            raise ValueError(
                f"{key} must be a nonempty string under 100,000 characters"
            )
    result = {k: row[k].strip() for k in fields}
    for key in ("latency_a_ms", "latency_b_ms", "cost_a_usd", "cost_b_usd"):
        value = row.get(key)
        if value is not None and (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
            or value < 0
        ):
            raise ValueError(f"{key} must be a finite nonnegative number or null")
        result[key] = value
    result["source"] = str(row.get("source", "imported"))
    return result


class Store:
    """Open one SQLite connection per operation for threaded local HTTP access."""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS votes(case_id TEXT, rater TEXT, winner TEXT, updated TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(case_id,rater));
                CREATE TABLE IF NOT EXISTS judges(case_id TEXT, provider TEXT, model TEXT, payload TEXT, updated TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(case_id,provider,model));
                CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
            """)
            db.execute(
                "INSERT OR IGNORE INTO meta VALUES (?,?)",
                ("salt", secrets.token_hex(32)),
            )

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Return a connection with a busy timeout for short concurrent writes."""
        db = sqlite3.connect(self.path, timeout=15)
        try:
            with db:
                yield db
        finally:
            db.close()

    def import_cases(self, rows: list[Record]) -> int:
        """Import atomically; reject conflicting IDs instead of invalidating votes."""
        if not isinstance(rows, list) or not 1 <= len(rows) <= 1000:
            raise ValueError("Import a JSON array of 1 to 1000 cases")
        cleaned = [validate_case(row) for row in rows]
        with self.connect() as db:
            for row in cleaned:
                payload = json.dumps(row, sort_keys=True)
                existing = db.execute(
                    "SELECT payload FROM cases WHERE id=?", (row["id"],)
                ).fetchone()
                if existing and existing[0] != payload:
                    raise ValueError(
                        f"Case {row['id']} already exists with different content. Use a new ID."
                    )
                db.execute(
                    "INSERT OR IGNORE INTO cases VALUES (?,?)", (row["id"], payload)
                )
        return len(cleaned)

    def cases(self) -> list[Record]:
        """Return source cases for export and internal evaluation."""
        with self.connect() as db:
            return [
                json.loads(r[0])
                for r in db.execute("SELECT payload FROM cases ORDER BY id")
            ]

    def case(self, case_id: str) -> Record:
        """Fetch one case or raise a useful input error."""
        with self.connect() as db:
            row = db.execute(
                "SELECT payload FROM cases WHERE id=?", (case_id,)
            ).fetchone()
        if not row:
            raise ValueError("Unknown case")
        return json.loads(row[0])  # type: ignore[no-any-return]

    def orientation(self, case_id: str, rater: str) -> bool:
        """Persistently randomize left/right for each case and reviewer."""
        if not rater.strip() or len(rater) > 100:
            raise ValueError("Reviewer ID is required (max 100 characters)")
        with self.connect() as db:
            salt = db.execute("SELECT value FROM meta WHERE key='salt'").fetchone()[0]
        return bool(
            hashlib.sha256(f"{salt}\0{case_id}\0{rater}".encode()).digest()[0] & 1
        )

    def blind_case(self, case_id: str, rater: str) -> Record:
        """Do not send model names, judge verdicts, or metrics until a vote exists."""
        row = self.case(case_id)
        swapped = self.orientation(case_id, rater)
        with self.connect() as db:
            vote = db.execute(
                "SELECT winner FROM votes WHERE case_id=? AND rater=?", (case_id, rater)
            ).fetchone()
        result: Record = {
            "id": case_id,
            "prompt": row["prompt"],
            "left": row["output_b" if swapped else "output_a"],
            "right": row["output_a" if swapped else "output_b"],
            "reviewed": bool(vote),
        }
        if vote:
            result.update(
                left_model=row["model_b" if swapped else "model_a"],
                right_model=row["model_a" if swapped else "model_b"],
                vote=vote[0],
            )
        return result

    def vote(self, case_id: str, rater: str, choice: str) -> None:
        """Map a blind vote to the canonical outputs and upsert one reviewer vote."""
        self.case(case_id)
        swapped = self.orientation(case_id, rater)
        if choice not in ("left", "right", "tie"):
            raise ValueError("Choose left, right, or tie")
        winner = (
            "tie"
            if choice == "tie"
            else ("output_b" if (choice == "left") == swapped else "output_a")
        )
        with self.connect() as db:
            db.execute(
                "INSERT INTO votes(case_id,rater,winner) VALUES (?,?,?) ON CONFLICT(case_id,rater) DO UPDATE SET winner=excluded.winner,updated=CURRENT_TIMESTAMP",
                (case_id, rater, winner),
            )

    def judge(self, case_id: str, provider: str, model: str, result: Record) -> None:
        """Store the latest verdict for this case and exact judge configuration."""
        self.case(case_id)
        if result.get("winner") not in WINNERS:
            raise ValueError("Invalid judge winner")
        with self.connect() as db:
            db.execute(
                "INSERT INTO judges(case_id,provider,model,payload) VALUES (?,?,?,?) ON CONFLICT(case_id,provider,model) DO UPDATE SET payload=excluded.payload,updated=CURRENT_TIMESTAMP",
                (case_id, provider, model, json.dumps(result, allow_nan=False)),
            )

    def export(self) -> Record:
        """Export cases, votes, and latest verdicts without the blinding salt."""
        with self.connect() as db:
            votes = [
                dict(case_id=a, rater=b, winner=c, updated=d)
                for a, b, c, d in db.execute("SELECT * FROM votes")
            ]
            judges = [
                dict(case_id=a, provider=b, model=c, result=json.loads(d), updated=e)
                for a, b, c, d, e in db.execute("SELECT * FROM judges")
            ]
        return {"cases": self.cases(), "votes": votes, "judges": judges}

    def stats(self) -> Record:
        """Keep provider/model agreement separate and report sample sizes."""
        data = self.export()
        groups: dict[str, list[tuple[str, str]]] = {}
        costs: dict[str, float] = {}
        latencies: dict[str, list[float]] = {}
        for j in data["judges"]:
            key = f"{j['provider']} / {j['model']}"
            groups.setdefault(key, [])
            for v in data["votes"]:
                if v["case_id"] == j["case_id"]:
                    groups[key].append((v["winner"], j["result"]["winner"]))
            cost = j["result"].get("cost_usd")
            if cost is not None:
                costs[key] = costs.get(key, 0) + cost
            latency = j["result"].get("latency_ms")
            if latency is not None:
                latencies.setdefault(key, []).append(latency)
        summary = []
        for key, pairs in groups.items():
            times = latencies.get(key, [])
            summary.append(
                dict(
                    judge=key,
                    **agreement(pairs),
                    cost_usd=costs.get(key),
                    mean_latency_ms=sum(times) / len(times) if times else None,
                )
            )
        models: dict[str, Record] = {}
        for case in data["cases"]:
            for side in ("a", "b"):
                name = case[f"model_{side}"]
                model = models.setdefault(
                    name,
                    {
                        "model": name,
                        "wins": 0,
                        "ties": 0,
                        "votes": 0,
                        "latencies": [],
                        "costs": [],
                    },
                )
                latency = case.get(f"latency_{side}_ms")
                cost = case.get(f"cost_{side}_usd")
                if latency is not None:
                    model["latencies"].append(latency)
                if cost is not None:
                    model["costs"].append(cost)
                for vote in data["votes"]:
                    if vote["case_id"] == case["id"]:
                        model["votes"] += 1
                        model["wins"] += vote["winner"] == f"output_{side}"
                        model["ties"] += vote["winner"] == "tie"
        candidates = []
        for model in models.values():
            times, prices = model.pop("latencies"), model.pop("costs")
            model["mean_latency_ms"] = sum(times) / len(times) if times else None
            model["mean_cost_usd"] = sum(prices) / len(prices) if prices else None
            candidates.append(model)
        return dict(
            candidates=candidates,
            cases=len(data["cases"]),
            votes=len(data["votes"]),
            judged_pairs=len(data["judges"]),
            judges=summary,
        )
