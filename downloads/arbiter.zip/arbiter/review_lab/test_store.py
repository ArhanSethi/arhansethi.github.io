"""Offline correctness tests for the review extension."""

import json
import threading
import urllib.request
from http.server import ThreadingHTTPServer

import pytest

from review_lab.__main__ import handler_for
from review_lab.store import Store, agreement


def row():
    return dict(
        id="x",
        prompt="Question",
        model_a="model-one",
        model_b="model-two",
        output_a="First",
        output_b="Second",
    )


def test_blinding_vote_and_persistence(tmp_path):
    path = tmp_path / "reviews.db"
    s = Store(path)
    s.import_cases([row()])
    blind = s.blind_case("x", "rater")
    assert "left_model" not in blind and "vote" not in blind
    expected = "output_a" if blind["left"] == "First" else "output_b"
    s.vote("x", "rater", "left")
    assert s.export()["votes"][0]["winner"] == expected
    assert s.blind_case("x", "rater")["reviewed"]
    s.vote("x", "rater", "tie")
    assert len(s.export()["votes"]) == 1 and s.export()["votes"][0]["winner"] == "tie"
    assert Store(path).orientation("x", "rater") == s.orientation("x", "rater")
    with pytest.raises(ValueError):
        s.vote("x", "rater", "bad")
    with pytest.raises(ValueError):
        s.blind_case("x", "")
    with pytest.raises(ValueError):
        s.case("missing")


def test_import_atomic_and_validation(tmp_path):
    s = Store(tmp_path / "db")
    s.import_cases([row()])
    with pytest.raises(ValueError):
        s.import_cases([dict(row(), id="new"), dict(row(), output_a="Changed")])
    assert len(s.cases()) == 1
    for payload in [
        [],
        [dict(row(), prompt="")],
        [dict(row(), cost_a_usd=float("nan"))],
    ]:
        with pytest.raises(ValueError):
            s.import_cases(payload)


def test_agreement_and_judge_groups(tmp_path):
    assert agreement([])["n"] == 0
    assert agreement([("tie", "tie")])["kappa"] is None
    assert agreement([("output_a", "output_a"), ("output_b", "output_b")])["kappa"] == 1
    s = Store(tmp_path / "db")
    s.import_cases([row()])
    s.vote("x", "rater", "tie")
    s.judge("x", "p", "judge", dict(winner="tie", cost_usd=0.01, latency_ms=50))
    stats = s.stats()
    assert stats["judges"][0]["agreement"] == 1
    s.judge("x", "p", "judge", dict(winner="output_a", cost_usd=0.02, latency_ms=70))
    assert s.stats()["judged_pairs"] == 1 and s.stats()["judges"][0]["agreement"] == 0
    assert s.stats()["judges"][0]["cost_usd"] == 0.02
    with pytest.raises(ValueError):
        s.judge("x", "p", "judge", {"winner": "bad"})


def test_http_import_vote_export(tmp_path):
    s = Store(tmp_path / "db")
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(s))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_port}"

    def post(path, payload):
        return urllib.request.urlopen(
            urllib.request.Request(
                base + path,
                data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"},
            )
        )

    try:
        assert post("/api/import", [row()]).status == 200
        assert post("/api/vote", dict(id="x", rater="test", choice="tie")).status == 200
        assert json.load(urllib.request.urlopen(base + "/api/stats"))["votes"] == 1
        assert urllib.request.urlopen(base + "/").status == 200
        assert (
            json.load(urllib.request.urlopen(base + "/api/export"))["votes"][0][
                "winner"
            ]
            == "tie"
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_live_adapter_uses_public_arbiter_api(monkeypatch):
    """Exercise the real adapter and public result model with the paid call mocked."""
    import asyncio

    import arbiter_ai
    from arbiter_ai.core.models import ComparisonResult
    from arbiter_ai.core.types import Provider
    from review_lab.__main__ import run_judge

    received = {}

    async def compare(**kwargs):
        received.update(kwargs)
        return ComparisonResult(
            output_a=kwargs["output_a"],
            output_b=kwargs["output_b"],
            winner="output_b",
            confidence=0.8,
            reasoning="Second response addresses the question.",
            processing_time=0.15,
        )

    monkeypatch.setattr(arbiter_ai, "compare", compare)
    result = asyncio.run(run_judge(row(), "openai", "test-model", "Accuracy"))
    assert result["winner"] == "output_b" and result["latency_ms"] == 150
    assert received["provider"] == Provider.OPENAI and received["model"] == "test-model"
    assert received["reference"] == "Question"


def test_candidate_metrics_use_supplied_measurements(tmp_path):
    s = Store(tmp_path / "db")
    s.import_cases([dict(row(), latency_a_ms=100, cost_a_usd=0.002)])
    s.vote("x", "rater", "tie")
    models = {m["model"]: m for m in s.stats()["candidates"]}
    assert models["model-one"]["mean_latency_ms"] == 100
    assert models["model-one"]["mean_cost_usd"] == 0.002
    assert models["model-one"]["ties"] == 1
    assert models["model-two"]["mean_cost_usd"] is None
