# Extension changes

- Adds review_lab/ as an independent local dashboard using the existing public compare() API.
- Adds atomic SQLite case imports, consistent per-reviewer blinding, saved votes, latest judge verdicts and JSON audit export.
- Adds human/judge exact agreement and Cohen kappa, plus human model preference summaries and optional supplied generation cost/latency.
- Does not change core library architecture, APIs, dependency metadata or existing tests.

See START_HERE.md for setup, limits, and source-file responsibilities.
