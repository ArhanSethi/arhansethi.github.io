"""Launch from the repository root with python examples/review_workbench.py."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from review_lab.__main__ import main  # noqa: E402

if __name__ == "__main__":
    main()
