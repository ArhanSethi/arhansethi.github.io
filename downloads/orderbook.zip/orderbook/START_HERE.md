# Order Book Replay

A browser replay dashboard backed by megabyde/order-book's C++ engine. Depth snapshots come from the actual C++ book, not a separate Python implementation.

## Run

Install Python 3.11+ and a C++14 compiler (`g++` or `clang++`) available on PATH. On Windows this can be a MinGW-w64 toolchain, or use the MSVC/CMake alternative below.

```powershell
py -3.12 replay/server.py
```

On macOS/Linux: `python3 replay/server.py`. Windows users can double-click `run.bat` once Python and a compiler are installed. The launcher compiles the engine into `build/` automatically when sources change. No Python packages are required.

Open **http://127.0.0.1:8012** and load the synthetic session. Select a symbol, play/pause, change speed (0.5× to 50×), step, reset, or seek with the slider. Playback follows the input event timestamps. Export downloads all loaded snapshots as JSONL.

### Windows with Visual Studio C++ tools and CMake

From a Developer PowerShell with CMake available:

```powershell
cmake -S . -B build -DBUILD_TESTS=OFF
cmake --build build --config Release
Copy-Item build\Release\order-book.exe build\order-book.exe
py -3.12 replay/server.py
```

Copy only if your generator produced the `Release/` subfolder. If the binary is older than edited sources, rebuild it before restarting the Python launcher.

## Input CSV

```csv
Time,Ticker,Order,T,Shares,Price
0,DEMO,buy-1,B,100,1000000
250,DEMO,sell-1,S,80,1000200
500,DEMO,buy-1,C,60,0
750,DEMO,sell-1,D,0,0
```

- Time: nondecreasing integer milliseconds. Playback uses relative differences.
- Price: integer units of **$0.0001** (1000000 means $100.00).
- Shares and Price: unsigned 32-bit fields; aggregated quantities use 64 bits.
- Ticker and Order: nonempty plain CSV text. No quoted commas or multiline fields.

| Event | Original engine behavior |
|---|---|
| B / S | Add a buy / sell order; IDs must be unique among active orders |
| C | Reduce the identified order **to** Shares, not **by** Shares; zero removes it |
| D | Delete identified order |
| E | Execute up to Shares using opposite-side liquidity |
| F | Execute the identified order's remaining quantity against the opposite side |
| T / X | Informational trade events; no book mutation |

**Important semantic limit:** the upstream E/F operations actively consume opposite-side FIFO liquidity and do not enforce the incoming order's limit price. This behavior is retained for compatibility. It is neither a general historical exchange-feed decoder nor a production matching engine. Real feeds need a format-specific adapter. Do not interpret an exchange's cancellation/execution messages as this format without checking their semantics.

The UI supports at most 20,000 events and 5 MB per upload, caches snapshots in the browser, and displays the top 12 of up to 100 depth levels emitted per side. Open-order count covers the entire book. The bundled 240-event, two-symbol session is synthetic.

## CLI and code

Legacy CLI output still works:

```sh
build/order-book replay/demo.csv
build/order-book replay/demo.csv --snapshots
```

Use `build\order-book.exe` on Windows. CSV mode emits best bid/ask changes. Snapshot mode emits JSON for every event.

- `order_book.h`: new depth export.
- `order_book.cpp`: fixes for deleting the last bid level, duplicate adds, and zero-quantity decreases.
- `order.h`: fixes aggregate quantity truncation in PQ construction.
- `event.h`, `main.cpp`: input validation, useful line errors, JSON snapshots, legacy CSV compatibility.
- `replay/server.py`: compile helper, bounded upload parsing, loopback HTTP server.
- `replay/index.html`: replay controls, depth/spread charts and tables.
- `replay/test_replay.py`: tests the compiled engine, including 64-bit aggregation and last-level execution.

```sh
python -m pip install pytest
python -m pytest replay/test_replay.py -q
```

Compiled binaries are omitted from the source download so you build for your own OS. The C++ build and regression tests were run on Linux; Windows build instructions have not been executed here.
