# Upstream attribution

This is an extended copy of [megabyde/order-book](https://github.com/megabyde/order-book), based on commit `bab688e0884fa1309da7ffb749ba2cef4a2de28c`.

The original authors own their original contributions. Their license, copyright notices, source files, and README are retained. New work is described in START_HERE.md and CHANGES.md. This package does not claim original authorship of the upstream project.

Extension title: Order Book Replay. New extension code is made available under the repository's MIT license terms.
