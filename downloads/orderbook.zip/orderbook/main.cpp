#include <fstream>
#include <unordered_map>
#include <iomanip>
#include <sstream>

std::string json_string(const std::string& value)
{
    std::ostringstream out;
    out << '"';
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c < 32) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(c);
        else out << c;
    }
    out << '"';
    return out.str();
}


#include "order_book.h"

void
print(std::ostream& os, uint64_t time, const std::string& ticker, PQ best_ask, PQ best_bid)
{
    os << time << ',' << ticker << ',';
    if (best_bid.price != 0)
        os << best_bid;
    else
        os << ',';
    os << ',';
    if (best_ask.price != 0)
        os << best_ask;
    else
        os << ',';
    os << '\n';
}

int
main(int argc, const char* argv[])
{
    const bool snapshots = argc == 3 && std::string(argv[2]) == "--snapshots";
    if (argc != 2 && !snapshots) {
        std::cout << "Usage: " << argv[0] << " FILE [--snapshots]\n";
        return 1;
    }

    std::ifstream input(argv[1]);
    if (!input.is_open()) { std::cerr << "Could not open input file\n"; return 1; }

    // Order books for each symbol
    std::unordered_map<std::string, OrderBook> books;

    std::string line;
    // Skip the header
    getline(input, line);
    size_t line_number = 1;
    uint64_t last_time = 0;
    while (getline(input, line)) {
        ++line_number;
        try {
        // Skip empty strings
        if (line.find_last_not_of(" \t\n\v\f\r") == std::string::npos)
            continue;

        // Parse event message
        Event event(line);
        if (event.time < last_time) throw std::invalid_argument("Events must be sorted by time");
        last_time = event.time;
        // Get the order book for this symbol
        auto& book = books[event.ticker];

        switch (event.type) {
        case Event::Type::Buy:
            book.buy(event.order, event.price, event.shares);
            break;
        case Event::Type::Sell:
            book.sell(event.order, event.price, event.shares);
            break;
        case Event::Type::Decrease:
            book.decrease(event.order, event.shares);
            break;
        case Event::Type::Delete:
            book.remove(event.order);
            break;
        case Event::Type::Execute:
            book.execute(event.order, event.shares);
            break;
        case Event::Type::Fill:
            book.fill(event.order);
            break;
        default:
            // Trades and cross-trades don't affect the order book
            break;
        }

        if (snapshots) {
            std::cout << "{\"time\":" << event.time << ",\"ticker\":" << json_string(event.ticker)
                      << ",\"event\":" << json_string(std::string(1, static_cast<char>(event.type))) << ",";
            book.snapshot(std::cout);
            std::cout << "}\n";
        } else if (book.changed()) {
            auto ask_bid = book.best_ask_bid();
            print(std::cout, event.time, event.ticker, ask_bid.first, ask_bid.second);
        }
        } catch (const std::exception& ex) {
            std::cerr << "Line " << line_number << ": " << ex.what() << "\n";
            return 2;
        }
    }

    return 0;
}
