# Extension changes

- Adds a --snapshots JSONL mode while preserving legacy best-bid/ask CSV output.
- Adds aggregate best-first bid and ask depth export to the original C++ OrderBook.
- Fixes invalid bid iterator decrement during execution of the last level and 32-bit truncation of aggregated quantity.
- Adds release-build duplicate/order validation, line-numbered parser errors, monotonic time validation and zero-quantity cancellation.
- Adds a loopback replay dashboard with event-time playback, seeking, symbol filtering, depth/spread charts and JSONL export.
- Adds an automatic compiler launcher and synthetic two-symbol session.

See START_HERE.md for setup, limits, and source-file responsibilities.
