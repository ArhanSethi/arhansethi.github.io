"""Build the original C++ engine and serve its snapshots in a local replay UI."""

import argparse
import csv
import io
import json
import os
import shutil
import subprocess
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build():
    out = ROOT / "build"
    out.mkdir(exist_ok=True)
    binary = out / ("order-book.exe" if os.name == "nt" else "order-book")
    sources = list(ROOT.glob("*.h")) + [ROOT / "main.cpp", ROOT / "order_book.cpp"]
    if binary.exists() and binary.stat().st_mtime >= max(
        p.stat().st_mtime for p in sources
    ):
        return binary
    compiler = shutil.which("g++") or shutil.which("clang++")
    if not compiler:
        raise RuntimeError(
            "Install a C++14 compiler (g++ or clang++), or build with CMake and place order-book.exe in build/. See START_HERE.md."
        )
    subprocess.run(
        [
            compiler,
            "-std=c++14",
            "-O2",
            "-Wall",
            "-Wextra",
            "-Werror",
            str(ROOT / "main.cpp"),
            str(ROOT / "order_book.cpp"),
            "-o",
            str(binary),
        ],
        check=True,
    )
    return binary


def snapshots(csv_text, binary):
    rows = list(csv.reader(io.StringIO(csv_text)))
    if not rows or rows[0][:6] != ["Time", "Ticker", "Order", "T", "Shares", "Price"]:
        raise ValueError("Header must be Time,Ticker,Order,T,Shares,Price")
    if not 1 < len(rows) <= 20001:
        raise ValueError("Provide between 1 and 20,000 events")
    # Normalize newline/CSV encoding before handing data to the original parser.
    for n, r in enumerate(rows[1:], 2):
        if len(r) < 6 or any("," in v or "\n" in v or "\r" in v for v in r):
            raise ValueError(f"Line {n}: expected six plain CSV fields")
    fd, path = tempfile.mkstemp(suffix=".csv")
    try:
        with os.fdopen(fd, "w", newline="") as f:
            writer = csv.writer(f, lineterminator="\n")
            writer.writerows(rows)
        result = subprocess.run(
            [str(binary), path, "--snapshots"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode:
            raise ValueError(
                result.stderr.strip() or "Engine rejected the event stream"
            )
        return [json.loads(line) for line in result.stdout.splitlines()]
    finally:
        os.unlink(path)


def handler_for(binary):
    class Handler(BaseHTTPRequestHandler):
        def send(self, data, status=200, kind="application/json"):
            body = (json.dumps(data) if kind == "application/json" else data).encode()
            self.send_response(status)
            self.send_header("Content-Type", kind)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == "/":
                self.send(
                    (ROOT / "replay/index.html").read_text(),
                    kind="text/html; charset=utf-8",
                )
            elif self.path == "/api/demo":
                try:
                    self.send(snapshots((ROOT / "replay/demo.csv").read_text(), binary))
                except Exception as ex:
                    self.send({"error": str(ex)}, 400)
            else:
                self.send({"error": "Not found"}, 404)

        def do_POST(self):
            if self.path != "/api/replay":
                self.send({"error": "Not found"}, 404)
                return
            if self.headers.get("Origin") and self.headers[
                "Origin"
            ] != "http://" + self.headers.get("Host", ""):
                self.send({"error": "Origin mismatch"}, 403)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 5_000_000:
                    raise ValueError("Upload limit is 5 MB")
                if "application/json" not in self.headers.get("Content-Type", ""):
                    raise ValueError("Send JSON")
                data = json.loads(self.rfile.read(length))
                self.send(snapshots(data["csv"], binary))
            except Exception as ex:
                self.send({"error": str(ex)}, 400)

    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8012)
    args = parser.parse_args()
    binary = build()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_for(binary))
    print(f"Order Book Replay: http://127.0.0.1:{args.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
