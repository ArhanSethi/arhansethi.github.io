"""Regression tests exercise actual compiled C++, not a duplicate Python engine."""

import subprocess

import pytest
from server import ROOT, build, snapshots


@pytest.fixture(scope="module")
def binary():
    return build()


def run(binary, body):
    return snapshots("Time,Ticker,Order,T,Shares,Price\n" + body, binary)


def test_depth_aggregation_and_64bit(binary):
    rows = run(
        binary, "0,X,a,B,3000000000,10000\n1,X,b,B,3000000000,10000\n2,X,c,S,50,10100\n"
    )
    assert rows[-1]["bids"] == [dict(price=10000, quantity=6000000000, orders=2)]
    assert rows[-1]["asks"][0]["quantity"] == 50


def test_last_bid_execution_and_zero_decrease(binary):
    rows = run(
        binary, "0,X,a,B,10,10000\n1,X,b,S,20,10100\n2,X,b,E,10,0\n3,X,b,C,0,0\n"
    )
    assert rows[2]["bids"] == [] and rows[2]["asks"][0]["quantity"] == 10
    assert rows[3]["order_count"] == 0


def test_bad_input_rejected(binary):
    for body in [
        "0,X,a,B,-1,100\n",
        "0,X,a,B,1,100\n1,X,a,B,1,100\n",
        "1,X,a,B,1,100\n0,X,b,S,1,200\n",
        "0,X,a,Z,1,100\n",
    ]:
        with pytest.raises(ValueError):
            run(binary, body)


def test_demo_and_legacy_mode(binary):
    rows = snapshots((ROOT / "replay/demo.csv").read_text(), binary)
    assert len(rows) == 240 and {r["ticker"] for r in rows} == {"DEMO", "TEST"}
    result = subprocess.run(
        [str(binary), str(ROOT / "replay/demo.csv")], capture_output=True, text=True
    )
    assert result.returncode == 0 and len(result.stdout.splitlines()[0].split(",")) == 6
