# Validation

Validation was performed on Linux / Python 3.12.

- C++ built successfully with g++ 13, C++14, -O2, -Wall, -Wextra and -Werror.
- 4 regression tests passed against the compiled executable: 64-bit aggregation, execution removing the last bid level, zero-quantity cancellation, malformed/duplicate/out-of-order input rejection, snapshot demo and legacy CSV output.
- Browser checks passed for loading 240 synthetic events, symbol filtering, seeking, playback, pause and reset. No JavaScript exceptions occurred.
- Windows/MSVC instructions were documented but not executed. Generated binaries are omitted from the download.
