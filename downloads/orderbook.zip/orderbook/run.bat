@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python replay/server.py
) else (
 py -3.12 replay/server.py
)
pause
