#pragma once

#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include <limits>
#include <cctype>

#include "utils.h"

/**
 * Class parsing a market event from an equity exchange.
 */
struct Event {
    enum struct Type : char {
        Buy        = 'B', // Buy order
        Sell       = 'S', // Sell order
        Decrease   = 'C', // Decrease the number of shares
        Delete     = 'D', // Delete the order
        Execute    = 'E', // Execute shares
        Fill       = 'F', // Fill the order completely
        Trade      = 'T', // Trade has occurred
        CrossTrade = 'X'  // Cross trade has occurred
    };

    Event() = delete;
    explicit Event(const std::string& s)
    {
        auto fields = split(s);
        if (fields.size() < 6) throw std::invalid_argument("Expected Time,Ticker,Order,T,Shares,Price");

        // We parse using the following format:
        // Time,Ticker,Order,T,Shares,Price,...
        auto number = [](const std::string& value) -> uint64_t {
            if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
                throw std::invalid_argument("Numeric fields must be unsigned integers");
            return std::stoull(value);
        };
        time   = number(fields[0]);
        ticker = fields[1];
        order  = fields[2];
        if (ticker.empty() || order.empty()) throw std::invalid_argument("Ticker and order ID required");
        if (fields[3].length() != 1 || std::string("BSCDEFTX").find(fields[3][0]) == std::string::npos)
            throw std::invalid_argument("Unsupported event type");
        type   = static_cast<Type>(fields[3][0]);
        auto parsed_shares = number(fields[4]);
        // Windows CSV may have CR at the end of its final field.
        if (!fields[5].empty() && fields[5].back() == '\r') fields[5].pop_back();
        auto parsed_price = number(fields[5]);
        if (parsed_shares > std::numeric_limits<uint32_t>::max() || parsed_price > std::numeric_limits<uint32_t>::max())
            throw std::out_of_range("Shares and price fields must fit uint32");
        shares = static_cast<uint32_t>(parsed_shares);
        price = static_cast<uint32_t>(parsed_price);
    }

    uint64_t    time;   // Milliseconds since the start of the trading day
    std::string ticker; // Stock symbol
    std::string order;  // Unique per-order ID
    Type        type;   // Message type
    uint32_t    shares; // Quantity of shares
    uint32_t    price;  // Order price in 100th of a penny
};
